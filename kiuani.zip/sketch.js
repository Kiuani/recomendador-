// comedia, açao, terror

// minha mae e uma peça, +12, comedia
// annabelle, +14, terror,misterio
// esquadrao suicida, +12, açao, fantasia
// gente grande, +12,comedia , drama
// velozes e furiosos, +14, açao, crime
// ladrões de bicicleta, 12, drama
// o menino que descobriu o vento, 14, drama


function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}