 // comedia, açao, terror

// minha mae e uma peça, +12, comedia
// annabelle, +14, terror,misterio
// esquadrao suicida, +12, açao, fantasia
// gente grande, +12,comedia , drama
// velozes e furiosos, +14, açao, aventura
// alice no pais das maravilhas , +10,infantil,aventura
// os farofeiros 2 ,+12,comedia 


let campoIdade;
let campoFantasia;
let campoAventura;

function setup() {
  createCanvas(800, 400);
  createElement("h2", "Recomendador de filmes");
  createSpan("Sua idade:");
  campoIdade = createInput("5");
  campoFantasia = createCheckbox("Gosta de fantasia?");
  campoAventura = createCheckbox("Gosta de aventura?");
}

function draw() {
  background("pink");
  let idade = campoIdade.value();
  let gostaDeFantasia = campoFantasia.checked();
  let gostaDeAventura = campoAventura.checked();
  let recomendacao = geraRecomendacao(idade, gostaDeFantasia, gostaDeAventura);

  fill(color(76, 0, 115));
  textAlign(CENTER, CENTER);
  textSize(38);
  text(recomendacao, width / 2, height / 2);
}

function geraRecomendacao(idade, gostaDeFantasia, gostaDeAventura) {
  if (idade >= 10) {
    if (idade >= 14) {
      return "minha mae e uma peça";
    } else {
      if (idade >= 12) {
        if(gostaDeFantasia || gostaDeAventura) {
          return "annabelle";          
        } else{
         return "esquadrao suicida";
        }
      } else {
        if (gostaDeFantasia) {
          return "gente grande";
        } else {
          return "velozes e furiosos";
        }
      }
    }
  } else {
    if (gostaDeFantasia) {
      return "alice no pais das maravilhas";
    } else {
      return "os farofeiros 2";
    }
  }
}
